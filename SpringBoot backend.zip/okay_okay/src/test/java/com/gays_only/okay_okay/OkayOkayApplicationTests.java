package com.gays_only.okay_okay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OkayOkayApplicationTests {

	@Test
	void contextLoads() {
	}

}
