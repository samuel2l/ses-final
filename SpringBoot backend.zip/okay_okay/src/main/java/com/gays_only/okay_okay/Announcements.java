package com.gays_only.okay_okay;

public class Announcements {
    public String title;
    public String content;
    public String date_created;
    public String by;

    Announcements(String title, String content, String date_created, String by) {
        this.title = title;
        this.content = content;
        this.date_created = date_created;
        this.by = by;
    }
}
