package com.gays_only.okay_okay;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

public class Database {
    private final String url = "jdbc:postgresql://localhost:5432/springboot";

    private final String user = "postgres";

    private final String password = "wotw3123";

    private Connection conn;

    Database() {
        this.conn = null;
        try {

            conn = DriverManager.getConnection(url, user, password);

            System.out.println("Connected to the PostgreSQL server successfully.");

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

    }

    public List<Student> get_users() {
        try {
            Vector<Student> res = new Vector<Student>(10, 3);
            Statement st = this.conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM students;");

            while (rs.next()) {
                res.addElement(
                        new Student(
                                rs.getLong("student_id"),
                                rs.getString("first_name"),
                                rs.getString("last_name"),
                                rs.getString("student_mail"),
                                rs.getString("department"),
                                rs.getInt("st_level"),
                                rs.getString("gender")));
            }
            return res;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public StudentAuth get_user_for_auth(long id) {
        try {
            PreparedStatement st = this.conn.prepareStatement("SELECT * FROM students_auth WHERE student_id = ?;");
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return new StudentAuth(rs.getLong("student_ID"), rs.getInt("pin"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    public Student get_user(long id) {
        try {
            PreparedStatement st = this.conn.prepareStatement("SELECT * FROM students WHERE student_id =?;");
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return new Student(
                        rs.getLong("student_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("student_mail"),
                        rs.getString("department"),
                        rs.getInt("st_level"),
                        rs.getString("gender"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    public Student get_user(String email) {
        try {
            Statement st = this.conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM students WHERE student_mail = '" + email + "'';");
            if (rs.next()) {
                return new Student(
                        rs.getLong("student_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("student_mail"),
                        rs.getString("department"),
                        rs.getInt("st_level"),
                        rs.getString("gender"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    public boolean insert_into_auth(long student_id, int pin) {
        try {
            Statement st = this.conn.createStatement();
            Boolean res = st.execute("INSERT INTO students_auth VALUES(" + student_id + ',' + pin + ");");
            return res;
        } catch (SQLException e) {
            System.out.println(e);
        }
        return false;
    }

    public String get_course_name(String course_id) {
        try {
            PreparedStatement ps = this.conn
                    .prepareStatement("SELECT course_name FROM all_courses WHERE course_code = ?;");
            ps.setString(1, course_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("course_name");
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    public List<Courses> get_all_courses() {
        try {
            Vector<Courses> v = new Vector<Courses>(5);

            PreparedStatement ps = this.conn
                    .prepareStatement("SELECT * FROM all_courses WHERE course_code = 'CPEN 201';");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                v.add(
                        new Courses(rs.getString("course_code"), rs.getString("course_name"),
                                rs.getInt("credit_hours")));
            }
            return v;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    public boolean register_course(long student_id, String code) {
        String course_name = get_course_name(code.strip());
        if (course_name == null) {
            return false;
        }
        try {
            PreparedStatement ps = this.conn.prepareStatement("INSERT INTO registered_courses VALUES(?,?,?)");
            ps.setLong(1, student_id);
            ps.setString(2, code);
            ps.setString(3, course_name);

            if (ps.executeUpdate() > 0) {
                return true;
            }

            return false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean unregister_course(long student_id, String code) {
        String course_name = get_course_name(code);
        System.out.println(code);
        System.out.println(student_id);
        if (course_name == null) {
            return false;
        }
        try {
            this.conn.createStatement().execute("SET session_replication_role = replica;");
            PreparedStatement ps = this.conn
                    .prepareStatement("DELETE FROM registered_courses WHERE student_id = ? AND course_code = ?;");
            ps.setLong(1, student_id);
            ps.setString(2, code);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                return true;
            }
            this.conn.createStatement().execute("SET session_replication_role = DEFAULT;");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public String dept_name_short(String department) {
        if (department.contains("Computer")) {
            return "CPEN";
        } else if (department.contains("Biomedical")) {
            return "BMEN";
        } else if (department.contains("Agricultural")) {
            return "AREN";
        } else if (department.contains("Material")) {
            return "MTEN";
        } else {
            return "FPEN";
        }
    }

    public List<Courses> get_registerable_courses(long student_id, String department, int level) {
        Vector<Courses> v = new Vector<Courses>(5);
        String dept = dept_name_short(department);

        String dep_course = String.format("%s %d%%", dept, level / 100);
        String gen_course = String.format("SENG %d%%", level / 100);

        try {
            PreparedStatement ps = this.conn
                    .prepareStatement("SELECT * FROM all_courses where course_code like ? OR course_code like ?;");
            ps.setString(1, dep_course);
            ps.setString(2, gen_course);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                v.add(
                        new Courses(rs.getString("course_code"), rs.getString("course_name"),
                                rs.getInt("credit_hours")));
            }
            return v;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }

    }

    public List<Courses> get_registered_courses(long student_id) {
        try {
            PreparedStatement st = this.conn.prepareStatement("SELECT * FROM registered_courses WHERE student_id = ?;");
            Vector<Courses> v = new Vector<Courses>(5);
            st.setLong(1, student_id);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                v.add(new Courses(rs.getString("course_code"), rs.getString("course_name"), rs.getInt("credit_hours")));
            }
            return v;
        } catch (SQLException e) {
            System.out.println(e);
        }

        return null;
    }

    public boolean insert_into_students(SignUpAuth auth) {
        try {
            PreparedStatement st = this.conn.prepareStatement(
                    "INSERT INTO students (student_id,first_name,last_name,student_mail,st_level,department,gender) VALUES (?,?,?,?,?,?,?);");
            st.setLong(1, auth.student_id);
            st.setString(2, auth.first_name);
            st.setString(3, auth.last_name);
            st.setString(4, auth.student_mail);
            st.setInt(5, auth.st_level);
            st.setString(6, auth.department);
            st.setString(7, auth.gender);
            st.executeUpdate();

            return true;
        } catch (SQLException e) {
            System.out.println(e);
        }
        return false;
    }

    public List<Announcements> get_announcements() {
        Vector<Announcements> v = new Vector<Announcements>(5, 3);
        try {
            Statement st = this.conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM announcements;");

            while (rs.next()) {
                v.add(new Announcements(
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getString("date_created"),
                        rs.getString("by_")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return v;
    }

    public List<Grades> get_my_grades(long student_id) {
        Vector<Grades> v = new Vector<Grades>(5);
        try {
            PreparedStatement ps = this.conn.prepareStatement("SELECT * FROM results WHERE student_id = ?;");
            ps.setLong(1, student_id);
            ResultSet rs = ps.executeQuery();
            // student_id | courses_id | grade
            while (rs.next()) {
                String course_id = rs.getString("courses_id");
                PreparedStatement ps1 = this.conn
                        .prepareStatement("SELECT * FROM all_courses WHERE course_code = ?;");
                ps1.setString(1, course_id);
                ResultSet rs1 = ps1.executeQuery();

                int credit_hours = 0;
                if (rs1.next()) {
                    credit_hours = rs1.getInt("credit_hours");
                }

                String course_name = this.get_course_name(course_id);
                v.add(
                        new Grades(
                                course_id, rs.getString("grade"), course_name, credit_hours));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("woah");
        }
        return v;
    }

}
