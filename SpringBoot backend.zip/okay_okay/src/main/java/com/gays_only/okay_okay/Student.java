package com.gays_only.okay_okay;

public class Student {
    long student_id;
    String first_name;
    String last_name;
    String student_mail;
    String department;
    int st_level;
    String gender;

    Student(long id, String fn, String ln, String mail, String department, int level, String gender) {
        this.student_id = id;
        this.student_mail = mail;
        this.last_name = ln;
        this.first_name = fn;
        this.department = department;
        this.st_level = level;
        this.gender = gender;
    }
}
