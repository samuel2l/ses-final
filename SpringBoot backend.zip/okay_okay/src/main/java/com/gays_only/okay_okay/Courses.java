package com.gays_only.okay_okay;

public class Courses {
    String code;
    String name;
    int credit;

    Courses() {
    }

    Courses(String code, String name, int credit) {
        this.code = code;
        this.name = name;
        this.credit = credit;
    }
}
