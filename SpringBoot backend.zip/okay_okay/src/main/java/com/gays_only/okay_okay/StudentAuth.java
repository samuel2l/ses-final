package com.gays_only.okay_okay;

public class StudentAuth {
    long id;
    int pin;

    StudentAuth(long id, int pin) {
        this.id = id;
        this.pin = pin;
    }
}
