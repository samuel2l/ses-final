package com.gays_only.okay_okay;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import io.jsonwebtoken.Claims;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

class Token {
    String token;

    Token() {
    }

    Token(String token) {
        this.token = token;
    }
}

class CourseId {
    String course;
}

@CrossOrigin
@RestController
public class Greeter {
    Database database = new Database();

    @GetMapping(value = "/get_all_users", produces = MediaType.APPLICATION_JSON_VALUE)
    public String index() {
        List<Student> students = this.database.get_users();
        return new Gson().toJson(students);
    }

    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public String login(@RequestBody StudentAuth auth) {

        StudentAuth sa = this.database.get_user_for_auth(auth.id);
        if (sa != null) {
            if (sa.pin == auth.pin) {
                Student student = this.database.get_user(sa.id);
                String token = JWT.createJWT(Long.toString(student.student_id), "SpringApp", new Gson().toJson(student),
                        -1);
                return "{\"token\" : \"" + token + "\"}";
            } else {
                return "{\"error\" : \" Incorrect pin\"}";
            }
        } else {
            return "{\"error\" : \"User has not been found.\"}";
        }
    }

    @PostMapping(value = "/signup", produces = MediaType.APPLICATION_JSON_VALUE)
    public String signup(@RequestBody String details) {
        try {
            SignUpAuth auth = new Gson().fromJson(details, SignUpAuth.class);
            if (this.database.get_user_for_auth(auth.student_id) != null) {
                return "{\"error\" : \"User id already registered.\"}";
            }
            if (this.database.get_user(auth.student_mail) != null) {
                return "{\"error\" : \"User mail has already been registered.\"}";
            }
            this.database.insert_into_auth(auth.student_id, auth.pin);
            this.database.insert_into_students(auth);

            return "{\"success\" : \"User has been registered.\"}";
        } catch (JsonSyntaxException j) {
            return "{\"error\" : \"Bad request.\"}";
        }

    }

    @GetMapping(value = "/user", produces = MediaType.APPLICATION_JSON_VALUE)
    public String decodejwt(@RequestHeader("auth") String token) {
        Claims claims = JWT.decodeJWT(token);
        long id = Long.parseLong(claims.getId());
        String student = claims.getSubject();
        Student st = new Gson().fromJson(student, Student.class);
        if (st.student_id == id) {
            return student;
        }
        return "{\"error\" : \"Invalid JWT.\"}";
    }

    @GetMapping(value = "/get_all_courses", produces = MediaType.APPLICATION_JSON_VALUE)
    public String get_all_courses() {
        return new Gson().toJson(this.database.get_all_courses());
    }

    @GetMapping(value = "/my_courses", produces = MediaType.APPLICATION_JSON_VALUE)
    public String my_courses(@RequestHeader("auth") String token) {

        try {

            Student student = new Gson().fromJson(this.decodejwt(token), Student.class);

            return new Gson().toJson(
                    this.database.get_registerable_courses(student.student_id, student.department, student.st_level));
        } catch (JsonSyntaxException e) {

            System.out.println(e.getMessage());
            return "{\"error\" : \"Invalid JWT.\"}";
        }
    }

    @GetMapping(value = "/grades", produces = MediaType.APPLICATION_JSON_VALUE)
    public String get_grades(@RequestHeader("auth") String token) {
        String student = this.decodejwt(token);
        try {

            Student st = new Gson().fromJson(student, Student.class);
            return new Gson().toJson(this.database.get_my_grades(st.student_id));

        } catch (JsonSyntaxException e) {
            System.out.println("127");
            System.out.println(e.getMessage());
        }
        return "{\"error\" : \"Invalid JWT.\"}";
    }

    @PostMapping(value = "/register_courses", produces = MediaType.APPLICATION_JSON_VALUE)
    public String register_courses(@RequestHeader("auth") String token, @RequestBody String courseId) {

        CourseId cid = new Gson().fromJson(courseId, CourseId.class);
        String student = this.decodejwt(token);
        try {
            Student student2 = new Gson().fromJson(student, Student.class);

            String course = cid.course;

            if (!this.database.register_course(student2.student_id, course)) {
                return String.format("{\"error\" : \"The course %s has not been found\"}", course);
            }

            return "{\"success\" : \"All courses have been registered.\"}";

        } catch (JsonSyntaxException e) {
            return student;
        }
    }

    // @PostMapping(value = "/register_courses", produces =
    // MediaType.APPLICATION_JSON_VALUE)
    // public String register_courses(@RequestHeader("auth") String token,
    // @RequestBody Vector<String> courses) {
    // Iterator<String> itr = courses.iterator();
    // String student = this.decodejwt(token);
    // try {
    // Student student2 = new Gson().fromJson(student, Student.class);
    // while (itr.hasNext()) {
    // String course = itr.next();

    // if (!this.database.register_course(student2.student_id, course)) {
    // return String.format("{\"error\" : \"The course %s has not been found\"}",
    // course);
    // }
    // }
    // return "{\"success\" : \"All courses have been registered.\"}";

    // } catch (JsonSyntaxException e) {
    // return student;
    // }
    // }

    @GetMapping(value = "/announcements", produces = MediaType.APPLICATION_JSON_VALUE)
    public String get_announcements() {
        return new Gson().toJson(this.database.get_announcements());
    }

    @DeleteMapping(value = "/course")
    public String delete(@RequestHeader("auth") String token, @RequestBody String course_id) {
        String student = this.decodejwt(token);
        CourseId cis = new Gson().fromJson(course_id, CourseId.class);
        try {
            Student s2 = new Gson().fromJson(student, Student.class);
            if (!this.database.unregister_course(s2.student_id, cis.course)) {
                return String.format("{\"error\" : \"The course %s has not been found\"}", course_id);
            }
            return "{\"success\" : \"All courses have been unregistered.\"}";

        } catch (JsonSyntaxException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    @PostMapping(value = "/unregister_courses", produces = MediaType.APPLICATION_JSON_VALUE)
    public String unregister_courses(@RequestHeader("auth") String token, @RequestBody Vector<String> courses) {
        Iterator<String> itr = courses.iterator();
        String student = this.decodejwt(token);
        try {
            Student student2 = new Gson().fromJson(student, Student.class);
            while (itr.hasNext()) {
                String course = itr.next();

                if (!this.database.unregister_course(student2.student_id, course)) {
                    return String.format("{\"error\" : \"The course %s has not been found\"}", course);
                }
            }
            return "{\"success\" : \"All courses have been unregistered.\"}";

        } catch (JsonSyntaxException e) {
            return student;
        }
    }

    @GetMapping(value = "/get_registered_courses", produces = MediaType.APPLICATION_JSON_VALUE)
    public String get_course(@RequestHeader("auth") String token) {
        String student = this.decodejwt(token);
        try {
            Student student2 = new Gson().fromJson(student, Student.class);

            return new Gson().toJson(this.database.get_registered_courses(student2.student_id));
        } catch (JsonSyntaxException e) {
            return student;
        }
    }

}