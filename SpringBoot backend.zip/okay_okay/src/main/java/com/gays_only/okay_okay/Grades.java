package com.gays_only.okay_okay;

public class Grades {
    String course_id;
    String grade;
    String course_name;
    int credit;

    Grades() {
    }

    Grades(String ci, String grade, String course_name, int credit) {
        this.course_id = ci;
        this.grade = grade;
        this.course_name = course_name;
        this.credit = credit;
    }
}
