package com.gays_only.okay_okay;

public class SignUpAuth {
    long student_id;
    String first_name;
    String last_name;
    String student_mail;
    String department;
    int st_level;
    String gender;
    int pin;
}
