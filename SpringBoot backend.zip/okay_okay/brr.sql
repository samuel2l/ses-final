CREATE TABLE students(
	student_ID bigint PRIMARY KEY,
	first_name VARCHAR NOT NULL,
	last_name VARCHAR NOT NULL,
	student_mail VARCHAR NOT NULL,
	st_level INT NOT NULL,
	department VARCHAR NOT NULL,
	gender varchar NOT NULL					 
 );

INSERT INTO students
VALUES (10961589,'Michael','Appiah','mappiah117@st.edu.gh',100,'Computer Engineering','M'),
       (10949533,'Ofori','Amoah Darkwa','aodarwah003@st.edu.gh',100,'Biomedical engineering','M'),
	   (10956661,'Daniel','Agudey Doe','dadoe002@st.edu.gh',100,'Agricultural engineering','M'),
	   (10956332,'Michael','Danso Lawerteh','mdlawerteh@st.edu.gh',100,'Material engineering','M'),
	   (10980811,'Kofi','Opoku Nyarko','konyarko003@st.edu.gh',100,'Food processing engineering','M'),
	   (10966173,'Larry','Wurapa Kwabena','@st.edu.gh',200,'Computer engineering','M'),
	   (10978425,'Saani ','Mustapha','mdsaani001@st.edu.gh',200,'Biomedical engineering','M'),
	   (10987644,'Evans','Acheampong','eaacheampong@st.edu.gh',200,'Agricultural engineering','M'),
	   (10986982,'Edward','Ayeribi Acquah','eaacquah018@st.edu.gh',200,'Material engineering','F'),
	   (10986424,'Sandra','Dery Kuuzume','sderry-kuuzume@st.edu.gh',200,'Food processing engineering','M'),
	   (10975556,'Emmanuel','Adofo Kofi','ekadofo002@st.edu.gh',300,'Computer engineering','M'),
	   (10941083,'Mawuena ','Efua Agbesi','niiabgesi@st.edu.gh',300,'Biomedical engineering','F'),
	   (10948975,'Freda','Acquah','facquah034@st.edu.gh',300,'Agricultural endineering','F'),
	   (10939629,'Nathaniel','Adikah','debtogouma@st.edu.gh',300,'Material engineering','M'),
	   (10957036,'Michelle','Owusu','mowusu119@st.edu.gh',300,'Food processing engineering','M'),
	   (10957340,'George','Anane Nyarko','nanegnana002@st.egu.gh',400,'computer engineering','M'),
	   (10947340,'Nicole','Brown','knbrown@st.edu.gh',400,'Biomedical engineering','F'),
	   (10980830,'Bernice','Boateng','baboateng027@st.edu.gh',400,'Agricultural engineering','F'),
	   (10980324,'Luqman','Nartey Quarshie','lnquarshie@st.edu.gh',400,'Material engineering','M'),
	   (10975589,'Ubaida','Abdul Fatawhu','uabdul-fatahu@st.edu.gh',400,'Food processing engineering','F');

CREATE TABLE all_courses(
course_code VARCHAR PRIMARY KEY,				
course_name VARCHAR NOT NULL,
credit_hours INT NOT NULL					
);
					
INSERT INTO all_courses
VALUES ('SENG 101','Calculus 1',4),
	   ('SENG 103','Mechanics I',3),
	   ('SENG 111','General physics',3),
	   ('SENG 105','Engineering Graphics',3),
	   ('SENG 106','Applied electricity',3),
	   ('CPEN 103','Computer engineering innovations',3),
	   ('BMEN 102','General biology',3),
	   ('AREN 114','Introduction to biosystems engineering',3),
	   ('MTEN 104','CAD/CAM',3),
	   ('SENG 201','Linear Algebra',4),
	   ('SENG 203','Strength of materials I',3),
	   ('SENG 207','Programming for engineers',3),
	   ('SENG 205','Fundamentals of thermodynamics',3),
	   ('AREN 211','Animal production',3),
	   ('BMEN 203','Intro to structure and properties of materials',3),
	   ('FPEN 201','Food process engineering calculations',3),
	   ('MTEN 203','Materials in our world',3),
	   ('CPEN 201','c++ programming',3),
	   ('CPEN 203','Digital circuits',3),
	   ('CPEN 213','Discrete mathematics',3),
	   ('CPEN 211','Database system design',3),
	   ('SENG 301','Numerical methods',3),
	   ('AREN 321','Engineering hydrology',3),
	   ('AREN 325','Surface irrigation',3),
	   ('AREN 343','Farm structures I',3),
	   ('AREN 323','Soil mechanics I',3),
	   ('BMEN 303','Bioinstrumentation',3),
	   ('BMEN 305','Biomaterials',3),
	   ('BMEN 307','Biomechanics',3),
	   ('BMEN 315','Research methodology',3),
	   ('FPEN 305','Introduction to food microbiology',3),
	   ('FPEN 309','Introduction to biotechnology',3),
	   ('FPEN 307','Product development in food processing',3),
	   ('FPEN 303','Engineering and design of food process I',3),
	   ('MTEN 301','Materials processing laboratory',3),
	   ('MTEN 303','Introduction to materials processing',3),
	   ('MTEN 311','Solid state technology',3),
	   ('MTEN 307','Phase equilibra of materials',3),
	   ('CPEN 301','Signals and systems',3),
	   ('CPEN 305','Computer networks',3),
	   ('CPEN 307','Operating systems',3),
	   ('CPEN 311','Object oriented programming',3),
	   ('SENG 401','Law for engineers',3),
	   ('AREN 421','Soil and water conservation engineering',3),
	   ('AREN 433','Technology of tractor and implement',3),
	   ('AREN 426','Agro meteorology and climatology',3),
	   ('AREN 436','Farm machine design',3),
	   ('BMEN 403','Biophysics',3),
	   ('BMEN 407','Medical signal and image processing',3),
	   ('BMEN 405','Cardiovasculare and respiratory systems machines',3),
	   ('BMEN 414','Biophotonics',3),
	   ('FPEN 413','Engineering design',3),
	   ('FPEN 409','Safety in food plants',3),
	   ('FPEN 406','Food packaging',2),
	   ('FPEN 404','Process control',2),
	   ('MTEN 403','Refractories',3),
	   ('MTEN 405','Process and quality control',3),
	   ('MTEN 401','Composite design and fabrication',3),
	   ('MTEN 413','Foundry technology',3),
	   ('CPEN 403','Embedded systems',3),
	   ('CPEN 419','Computer vision',3),
	   ('CPEN 401','Control systems analysis and design',3),
	   ('CPEN 424','Robotics',3);
	   
CREATE TABLE registered_courses(
	student_id bigint references students(student_id ) on delete cascade not null,
	course_code varchar references all_courses(course_code) on delete cascade not null,
	course_name VARCHAR NOT NULL		   
  );

INSERT into registered_courses
values
(10949533,'SENG 105','Engineering Graphics'),
(10949533,'SENG 111','General physics'),
(10949533,'BMEN 102','General biology'),
(10980811,'SENG 111','General physics'),
(10987644,'AREN 211','Animal production'),
(10975556,'CPEN 311','Object oriented programming'),
(10975556,'CPEN 307','Operating systems'),
(10949533,'SENG 101','Calculus 1'),
(10949533,'SENG 106','Applied electricity'),
(10987644,'SENG 205','Fundamentals of thermodynamics'),
(10975589,'FPEN 413','Engineering design'),
(10947340,'BMEN 414','Biophotonics'),
(10956661,'AREN 436','Farm machine design');

create table lecturers ( name varchar not null,
	department varchar not null,
	course_taken varchar references all_courses(course_code) on delete cascade not null,
	email varchar not null
);

insert into lecturers
	values
	('Dr. Godfrey Mills','Computer Engineering','CPEN 301','gdmill@gmail.com'),
	('Gifty Osei','Computer Engineering','CPEN 403','os1098@gmail.com'),
	('Dr. Prosper Afriyie','Computer Engineering','CPEN 401','olima@gmail.com'),
	('Anderson Mon','Biomedical Engineering','BMEN 405','andmon@gmail.com'),
	('Goerge Anni','Computer Engineering','CPEN 301','ann23geo3@gmail.com'),
	('Dr. Godfrey Mills','Computer Engineering','CPEN 401','gdmill@gmail.com'),
	('Dr. Godfrey Mills','Computer Engineering','CPEN 403','gdmill@gmail.com'),
	('Gifty Osei','Computer Engineering','CPEN 307','os1098@gmail.com'),
	('Frank Nsaful','Food processing engineering', 'FPEN 303', 'fnsaful@ug.edu.gh'),
    ('Victus Atanga','Food processing engineering', 'FPEN 309', 'vasanga@ug.edu.gh'),
	('E. Essien','Agricultural engineering', 'AREN 325','eesien@ug.edu.gh'),
    ('S.Y. Dorvlo','Agricultural engineering','AREN 211', 'sydorvlo@ug.edu.gh'),
	('John K. Bediako','Food processing engineering', 'FPEN 404', 'jkbediako@ug.edu.gh'),
    ('Frank Nsaful','Food processing engineering', 'FPEN 406','jkbediako@ug.edu.gh'),
	('Dr. Sharon N. Affrifah','Materials engineering', 'MTEN 311', 'snaffrifah@ug.edu.gh'),
    ('Dr. Parry-Hanson Kunadu','Materials engineering' , 'MTEN 413','phkunadu@ug.edu.gh'),
    ('A.A. Mahama','Agricultural engineering', 'AREN 343', 'aamahama@ug.edu.gh'),
    ('Bright J.A.Y. Sorgbey','Materials engineering', 'MTEN 311','bjaysorgbey@ug.edu.gh');


CREATE TABLE exam_timetable(course_code VARCHAR references all_courses(course_code)  on delete cascade not null,
					  duration_in_hrs INT NOT NULL,
					  venue VARCHAR NOT NULL,
					  exam_date DATE NOT NULL,
					  start_time_AM TIME NOT NULL
					  );
					  
					 
INSERT INTO exam_timetable
VALUES ('SENG 101',3,'SF-F1','2023-04-08','1:30'),
       ('SENG 103',3,'SF-F2','2023-04-12','8:30'),
	   ('SENG 111',2,'WW-S1','2023-04-13','9:30'),
	   ('SENG 105',2,'UGCS R2','2023-04-16','11:00'),
	   ('SENG 106',2,'GCB','2023-04-17','9:00'),
       ('CPEN 103',1,'Huawei Lab','2023-04-19','7:30'),
	   ('BMEN 102',2,'WW-S2','2023-04-19','3:00'),
	   ('AREN 114',2,'EW-S2','2023-04-20','1:30'),
	   ('MTEN 104',2,'NNB-R1','2023-04-20','12:30'),
	   ('SENG 201',3,'EW-S1','2023-04-09','1:00'),
	   ('SENG 203',2,'GCB','2023-04-11','3:00'),
	   ('SENG 207',3,'SES Computer lab','2023-04-12','11:30'),
	   ('SENG 205',2,'EW-S3','2023-04-14','5:00'),
	   ('AREN 211',1,'WW-S2','2023-04-16','1:00'),
	   ('BMEN 203',2,'GCB','2023-04-20','8:00'),
	   ('FPEN 201',2,'EW-S3','2023-04-20','10:00'),
	   ('MTEN 203',3,'UGCS R3','2023-04-21','10:30'),
	   ('CPEN 201',3,'Huawei Lab','2023-04-10','7:30'),
	   ('CPEN 203',2,'Huawei Lab','2023-04-19','7:30'),
	   ('CPEN 213',3,'Huawei Lab','2023-04-18','12:00'),
	   ('CPEN 211',2,'EW-S1','2023-04-23','4:30'),
	   ('SENG 301',3,'GCB','2023-04-08','4:00'),
	   ('AREN 321',1,'EW-S1','2023-04-09','5:30'),
	   ('AREN 325',2,'EW-21','2023-04-11','5:00'),
	   ('AREN 343',2,'SF-F2','2023-04-12','3:00'),
	   ('AREN 323',3,'SF-F2','2023-04-14','1:30'),
	   ('BMEN 303',3,'NNB R3','2023-04-14','1:30'),
       ('BMEN 305',2,'WW-S2','2023-04-15','2:30'),
	   ('BMEN 307',3,'WW-S1','2023-04-17','2:00'),
	   ('BMEN 315',3,'NNB R1','2023-04-18','1:00'),
	   ('FPEN 305',3,'WW-S1','2023-04-15','2:30'),
	   ('FPEN 309',3,'Huawei Lab','2023-04-19','7:30'),
	   ('FPEN 307',2,'GCB','2023-04-20','8:00'),
	   ('FPEN 303',1,'WW-S2','2023-04-16','1:00'),
	   ('MTEN 301',3,'WW-S1','2023-04-13','9:30'),
	   ('MTEN 303',3,'SF-F1','2023-04-08','1:30'),
	   ('MTEN 311',2,'UGCS R3','2023-04-21','10:30'),
	   ('MTEN 307',3,'EW-S1','2023-04-23','4:30'),
	   ('CPEN 301',3,'UGCS R2','2023-04-16','11:00'),
	   ('CPEN 305',3,'Huawei Lab','2023-04-18','12:00'),
	   ('CPEN 307',2,'SF-F2','2023-04-14','1:30'),
	   ('CPEN 311',3,'EW-21','2023-04-11','5:00'),
	   ('SENG 401',3,'GCB','2023-04-20','8:00'),
	   ('AREN 421',1,'NNB R1','2023-04-18','1:00'),
	   ('AREN 433',3,'UGCS R3','2023-04-21','10:30'),
	   ('AREN 426',3,'WW-S1','2023-04-15','2:30'),
	   ('AREN 436',2,'SF-F1','2023-04-08','1:30'),
	   ('BMEN 403',3,'WW-S1','2023-04-17','2:00'),
	   ('BMEN 407',3,'WW-S1','2023-04-15','2:30'),
	   ('BMEN 405',2,'EW-S1','2023-04-09','5:30'),
	   ('BMEN 414',3,'WW-S1','2023-04-13','9:30'),
	   ('FPEN 413',3,'WW-S2','2023-04-19','3:00'),
	   ('FPEN 409',3,'EW-S1','2023-04-09','5:30'),
	   ('FPEN 406',2,'WW-S1','2023-04-15','2:30'),
	   ('FPEN 404',2,'WW-S1','2023-04-13','9:30'),
	   ('MTEN 403',3,'WW-S1','2023-04-13','9:30'),
	   ('MTEN 405',3,'Huawei Lab','2023-04-19','7:30'),
	   ('MTEN 401',3,'WW-S2','2023-04-19','3:00'),
	   ('MTEN 413',3,'GCB','2023-04-17','9:00'),
	   ('CPEN 403',2,'GCB','2023-04-08','4:00'),
	   ('CPEN 419',3,'NNB R1','2023-04-18','1:00'),
	   ('CPEN 401',3,'NNB R3','2023-04-14','1:30'),
	   ('CPEN 424',3,'EW-S3','2023-04-20','10:00');
	   
create table exam_registration(Exam_Id serial not null,
id_student bigint not null primary key,
courses_code varchar references all_courses(course_code)
);

insert into exam_registration(id_student,courses_code)
values 
       (10980811,'SENG 111'),
       (10949533,'SENG 101'),
       (10975589,'FPEN 413'), 
       (10969689,'CPEN 103'),
	   (10978425,'BMEN 102'),
	   (10900075,'AREN 114'),
	   (10986983,'MTEN 104'),
	   (10987983,'SENG 201'),
	   (10947341,'SENG 203'),
	   (10970040,'SENG 207'),
	   (10939629,'SENG 205'),
	   (10948975,'AREN 211'),
	   (10961283,'BMEN 203'),
	   (10986024,'FPEN 201'),
	   (10987852,'MTEN 203'),
	   (10975556,'CPEN 201'),
	   (10976556,'CPEN 203'),
	   (10979896,'CPEN 213'),
	   (10973326,'CPEN 211'),
	   (10975756,'SENG 301'),
	   (10989975,'AREN 321'),
	   (10953375,'AREN 325'),
	   (10949975,'AREN 343'),
	   (10948976,'AREN 323'),
	   (10941083,'BMEN 303'),
       (10941183,'BMEN 305'),
	   (10947340,'BMEN 307'),
	   (10949340,'BMEN 315'),
	   (10986424,'FPEN 305'),
	   (10986534,'FPEN 309'),
	   (10957036,'FPEN 307'),
	   (10905736,'FPEN 303'),
	   (10986982,'MTEN 301'),
	   (10986412,'MTEN 303'),
	   (10980324,'MTEN 311'),
	   (10563324,'MTEN 307'),
	   (10969589,'CPEN 301'),
	   (10965349,'CPEN 305'),
	   (10991589,'CPEN 307'),
	   (10932189,'CPEN 311'),
	   (10961589,'SENG 401'),
	   (10948923,'AREN 421'),
	   (10973975,'AREN 433'),
	   (10956775,'AREN 426'),
	   (10948895,'AREN 436'),
	   (10951340,'BMEN 403'),
	   (10943740,'BMEN 407'),
	   (10978025,'BMEN 405'),
	   (10908425,'BMEN 414'),
	   (10985643,'FPEN 413'),
	   (10986524,'FPEN 409'),
	   (10987784,'FPEN 406'),
	   (10980074,'FPEN 404'),
	   (10989082 ,'MTEN 403'),
	   (10989682 ,'MTEN 405'),
	   (10926982 ,'MTEN 401'),
	   (10900982 ,'MTEN 413'),
	   (10983556,'CPEN 403'),
	   (10999556,'CPEN 419'),
	   (10976756,'CPEN 401'),
	   (10942556,'CPEN 424');

create  table results(
student_id bigint references exam_registration(id_student),
courses_id varchar references all_courses(course_code),
grade varchar  not null default 'None'	


);
insert into results 
values
       (10975589,'FPEN 413','A'),
       (10949533,'SENG 101','B+'),
       (10980811,'SENG 111','C'),
       (10980811,'SENG 111','C+'),
       (10949533,'SENG 101','D'),
       (10975589,'FPEN 413','A'), 
       (10961589,'CPEN 103','E'),
	   (10978425,'BMEN 102','F'),
	   (10948975,'AREN 114','D+'),
	   (10986982,'MTEN 104','B'),
	   (10986982,'SENG 201','C+'),
	   (10947340,'SENG 203','E'),
	   (10947340,'SENG 207','C'),
	   (10939629,'SENG 205','A'),
	   (10948975,'AREN 211','A'),
	   (10941083,'BMEN 203','B+'),
	   (10986424,'FPEN 201','A'),
	   (10986982,'MTEN 203','A'),
	   (10975556,'CPEN 201','E'),
	   (10975556,'CPEN 203','F'),
	   (10975556,'CPEN 213','C+'),
	   (10975556,'CPEN 211','C'),
	   (10975556,'SENG 301','C'),
	   (10948975,'AREN 321','A'),
	   (10948975,'AREN 325','B'),
	   (10948975,'AREN 343','A'),
	   (10948975,'AREN 323','B+'),
	   (10941083,'BMEN 303','B'),
       (10941083,'BMEN 305','D'),
	   (10947340,'BMEN 307','F'),
	   (10947340,'BMEN 315','A'),
	   (10986424,'FPEN 305','D+'),
	   (10986424,'FPEN 309','B'),
	   (10957036,'FPEN 307','F'),
	   (10957036,'FPEN 303','F'),
	   (10986982,'MTEN 301','D+'),
	   (10986982,'MTEN 303','A'),
	   (10980324,'MTEN 311','A'),
	   (10980324,'MTEN 307','A'),
	   (10961589,'CPEN 301','A'),
	   (10961589,'CPEN 305','A'),
	   (10961589,'CPEN 307','B'),
	   (10961589,'CPEN 311','B+'),
	   (10961589,'SENG 401','C+'),
	   (10948975,'AREN 421','C'),
	   (10948975,'AREN 433','A'),
	   (10948975,'AREN 426','E'),
	   (10948975,'AREN 436','C'),
	   (10947340,'BMEN 403','B'),
	   (10947340,'BMEN 407','D+'),
	   (10978425,'BMEN 405','F'),
	   (10978425,'BMEN 414','D'),
	   (10986424,'FPEN 413','A'),
	   (10986424,'FPEN 409','A'),
	   (10986424,'FPEN 406','A'),
	   (10986424,'FPEN 404','B+'),
	   (10986982 ,'MTEN 403','C'),
	   (10986982 ,'MTEN 405','F'),
	   (10986982 ,'MTEN 401','C+'),
	   (10986982 ,'MTEN 413','D+'),
	   (10975556,'CPEN 403','A'),
	   (10975556,'CPEN 419','A'),
	   (10975556,'CPEN 401','A');
	   
select * from results;
create table deleted_student_grade(
student_id bigint references exam_registration(id_student),
courses_id varchar references all_courses(course_code),
grade varchar  default('None')	
);

create or replace function deleted_student_grade_func()
	returns trigger as
	$body$
	begin
	insert into deleted_student_grade
	values(old.student_id,old.courses_id,old.grade);
	return new;
	
	end;
	$body$
	language plpgsql;
	create trigger deleted_student_grade_trigger
	before delete 
	on results
	for each row 
	execute procedure deleted_student_grade_func();
	delete from results
	where student_id=10949533;

select * from deleted_student_grade;


create table previous_student_grade(
student_id bigint references exam_registration(id_student),
courses_id varchar references all_courses(course_code),
grade varchar  default('None')	 
);

create or replace function previous_student_grade_func()
	returns trigger as
	$body$
	begin
	insert into previous_student_grade
	values(old.student_id,old.courses_id,old.grade);
	return new;
	
	end;
	$body$
	language plpgsql;	
	create trigger previous_student_grade_trigger
	before update 
	on results
	for each row 
	execute procedure previous_student_grade_func();
	update  results
	set grade='A+'
	where student_id=10975589 and courses_id='FPEN 413';

select * from previous_student_grade;


--trigger for when a student unregisters
create table unregistered_courses_log(
student_ID bigint references students(student_id),
course_id varchar references all_courses(course_code),
course_name varchar not null	
);

create function unregister_trigger_func()
	returns trigger
	language plpgsql
	as
	$body$
	begin
	insert into unregistered_courses_log
	values(old.student_id,old.course_code,old.course_name);
	return new;
	
	end;
	$body$;
	
	create trigger unregister_trigger
	before delete 
	on registered_courses
	for each row 
	execute procedure unregister_trigger_func();

delete from registered_courses
	where course_code='SENG 105'
	and student_id=10949533;
	
	select * from unregistered_courses_log;




--trigger for when a student leaves the school
create table unavailable_students_log(
student_id bigint primary key,
first_name varchar not null,
last_name varchar not null,
ug_mail varchar not null,	
level int not null,
department varchar not null,
gender varchar not null
);	
create or replace function dismembered_students_trigger_func()
	returns trigger as
	$body$
	begin
	insert into unavailable_students_log
	values(old.student_id,old.first_name,old.last_name,old.student_mail,old.st_level,old.department,old.gender);
	return new;
	
	end;
	$body$
	language plpgsql;
	create trigger dismemberedd_students_trigger
	before delete 
	on students
	for each row 
	execute procedure dismembered_students_trigger_func();


	delete from students
	where student_id=10949533;
select * from unavailable_students_log;