CREATE TABLE announcements (
  announcement_id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT,
  date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  by_ VARCHAR(255)
)