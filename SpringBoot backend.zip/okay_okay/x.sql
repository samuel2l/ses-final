
INSERT INTO results (student_id, courses_id, grade)
VALUES
(10970199, 'SENG 111', 'A'),
(10970199, 'CPEN 103', 'A');