import { useState } from "react";
import Login from "./Login";
import axios from "axios";



export default function Grades() {
    var [grades, setGrades] = useState({});
    var [user, setUser] = useState({});

    const options =  {
        headers : {
            'auth' : localStorage.getItem('jwt')
        }
    }
        
    if (localStorage.getItem('jwt') == null) {
        return <Login />;
    }
    
    axios.get('http://127.0.0.1:8080/user', options)
    .then((res) => {
        setUser(res.data)
    })
    axios.get('http://127.0.0.1:8080/grades', options)
    .then((res) => {
        setGrades(res.data)
    })

    
    return <div className="d-flex justify-content-center mr-2" style={
            {
                marginRight: '5em', 
                marginLeft: '5em' 
            }
    }
        >
    <div className="d-flex justify-content-center flex-column">
        <h1 className="mb-9" style={ {
            textAlign: "center",
            marginBottom: "0.5em"
        }}>
            Grades
        </h1>

        <div class="d-flex justify-content-between">
            <p className="fs-3" id="firstname">{user['first_name']} Grades</p>
            <a href="/logout" class="text-decoration-none fw-bold">Logout</a>
        </div>
        <div>
            {grades}
        </div>

    </div>
</div>

}