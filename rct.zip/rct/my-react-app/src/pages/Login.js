import MyLogo from './../esug.jpg'
import Dashboard from './Dashboard';

const handle_submit = () => {

    let student_id = document.getElementById("student_id").value;
    let password = document.getElementById("student_password").value;

    fetch (
        'http://127.0.0.1:8080/login', {
            method : 'POST',
            headers :  {
                "Content-Type" : "application/json"
            },
            body : JSON.stringify({
                'id' : student_id,
                'pin' : password
            })
        }
    ).then (
        res => res.json()
    ).then (
        res => {
            if (res['token'] !== undefined) {
                localStorage.setItem('jwt', res['token'])
                window.location = '/dashboard'
            } else {
                alert(res['error'])
            }
        }
    )
}

export default function Login() {
    console.log(localStorage.getItem('jwt'));
    if (localStorage.getItem('jwt') != null || localStorage.getItem('jwt') != undefined) {
        return <Dashboard />;
    }
    return <div className="d-flex justify-content-center" style={{ width : '100%' }}>
    <div className="d-flex justify-content-center flex-column"
        style={ {
            width: 'fit-content'
        } }
    >
        <h1 className="mb-9" style={ {
            textAlign: "center",
            marginBottom: "0.5em"
        }}>
            Log In
        </h1>
        <form id="loginform">
            <div class="mb-3">
                <div class="col">
                    <img src={MyLogo} alt="Esug Logo" />
                </div>
            </div>
            <div class="mb-3">
                <div class="col">
                    <input type="text" id="student_id" name="id" class="form-control" placeholder="User ID" aria-label="ID"/>
                </div>
            </div>
            <div class="mb-3">
                <div class="col">
                    <input type="password" id="student_password" name="password" class="form-control" placeholder="Password" aria-label="Student Level"/>
                </div>
            </div>
            
            <a id="sbmt" href='#' class="btn btn-primary" onClick={handle_submit}>Log In</a>
        </form>

    </div>
 
</div>

}